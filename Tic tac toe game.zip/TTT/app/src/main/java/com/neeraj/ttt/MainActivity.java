package com.neeraj.ttt;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
public class MainActivity extends AppCompatActivity {
    private boolean  running = true;
    private static final String OUT = "8851";
    boolean toggle = true;
    // 1:  X sign, 2:  O sign,  0:  empty
    int[] state = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    int[][] win = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onDropIn(View view) {
        if (!running) {
            return;
        }
        // get tapped location at board
        int loc = Integer.parseInt(view.getTag().toString());
        Log.i(OUT, String.valueOf(loc));
        // check for empty location
        if (state[loc] != 0) {
            return;
        }
        ImageView currentImageView = (ImageView) view;
        if (toggle) {
            currentImageView.setImageResource(R.drawable.x);
            state[loc] = 1;
            toggle = false;
        } else {
            currentImageView.setImageResource(R.drawable.o);
            state[loc] = 2;
            toggle = true;
        }
        currentImageView.setTranslationY(-1500);
        currentImageView.animate().translationYBy(1500).setDuration(200);
        Log.i(OUT, "state = " + Arrays.toString(state));
        for (int[] checkWin : win)
        {
            if (state[checkWin[0]] == state[checkWin[1]]
                    && state[checkWin[1]] == state[checkWin[2]]
                    && state[checkWin[1]] != 0)
            {
                Toast.makeText(this, "Congratulation" + (toggle? " O is winner": " X is winner") , Toast.LENGTH_SHORT).show();
                Log.i(OUT, " checkWin" + Arrays.toString(checkWin));
                running = false;
                return;
            }
        }
    }
    public void playAgain(View view) {
        recreate();
    }
}